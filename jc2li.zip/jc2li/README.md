jc2li
=====

This is JC-CLI, it is just another command line interface framwework making use
of python prompt_toolkit module.

